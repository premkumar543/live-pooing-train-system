import React, { useEffect, useState, useRef } from 'react';
import { socket } from './socket';

function useSessionName() {
  const [name, setName] = useState(() => sessionStorage.getItem('student_name') || '');
  function save(n) { sessionStorage.setItem('student_name', n); setName(n); }
  return [name, save];
}

export default function Student(){
  const [name, setName] = useSessionName();
  const [entered, setEntered] = useState(name || '');
  const [activePoll, setActivePoll] = useState(null);
  const [polls, setPolls] = useState([]);
  const [selected, setSelected] = useState(null);
  const [chat, setChat] = useState([]);
  const [msg, setMsg] = useState('');
  const [students, setStudents] = useState([]);
  const [timeLeft, setTimeLeft] = useState(0);
  const timerRef = useRef(null);

  useEffect(() => {
    socket.connect();
    if (name) socket.emit('student:join', { name }, ()=>{});
    socket.on('server:polls_state', data => {
      setPolls(data.polls || []);
      const a = (data.polls||[]).find(p => p.active);
      setActivePoll(a || null);
      if (a) startTimer(a.duration);
    });
    socket.on('server:poll_new', ({ poll }) => { setActivePoll(poll); startTimer(poll.duration); });
    socket.on('server:poll_update', ({ poll }) => setPolls(prev => prev.map(x=>x.id===poll.id?poll:x)));
    socket.on('server:poll_ended', ({ poll }) => { setActivePoll(null); clearTimer(); setPolls(prev => prev.map(x=>x.id===poll.id?poll:x)); });
    socket.on('server:students_update', ({ students }) => setStudents(students));
    socket.on('server:chat_history', ({ chat }) => setChat(chat || []));
    socket.on('chat:new', (entry) => setChat(c=>[...c, entry]));
    socket.on('server:kicked', ({ reason }) => { alert('You were removed: ' + reason); try{ socket.disconnect(); }catch(e){} });

    return () => { socket.off(); socket.disconnect(); clearTimer(); };
  }, [name]);

  function join() {
    if (!entered.trim()) return alert('Enter name');
    setName(entered.trim());
    socket.connect();
    socket.emit('student:join', { name: entered.trim() });
  }

  function startTimer(sec){
    setTimeLeft(sec);
    clearTimer();
    timerRef.current = setInterval(()=> {
      setTimeLeft(t => {
        if (t <= 1) { clearTimer(); return 0; }
        return t-1;
      });
    }, 1000);
  }
  function clearTimer(){ if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; } }

  function submit(pollId, optId){
    socket.emit('student:answer', { pollId, optionId: optId }, (r)=> {
      if (!r.ok) alert('Error: ' + (r.error||''));
      else setSelected(optId);
    });
  }

  function sendChat(){ if (!msg.trim()) return; socket.emit('chat:send', { name, text: msg }, (r)=> { if (r.ok) setMsg(''); }); }

  if (!name) {
    return (
      <div className="center">
        <h2>Let's Get Started</h2>
        <p>If you're a student, you'll be able to submit your answers, participate in live polls, and see how your responses compare with classmates</p>
        <input value={entered} onChange={e=>setEntered(e.target.value)} placeholder="Enter your name" />
        <button onClick={join}>Continue</button>
      </div>
    );
  }

  return (
    <div className="student-wrap">
      <header><h2>Welcome, {name}</h2></header>
      {activePoll ? (
        <div className="card poll-active">
          <div className="poll-head">
            <div><b>{activePoll.question}</b></div>
            <div className="timer">⏱ {timeLeft}s</div>
          </div>
          <div className="options">
            {activePoll.options.map(o => (
              <div key={o.id} className="option">
                <button disabled={!!selected} onClick={()=>submit(activePoll.id, o.id)}>{o.text}</button>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="waiting"><div className="loader">C</div><div>Wait for the teacher to ask questions..</div></div>
      )}

      <div className="bottom-grid">
        <div className="card">
          <h4>Past Polls</h4>
          {polls.map(p => (
            <div key={p.id} className="poll-card">
              <div>{p.question} {p.active && <small>(Active)</small>}</div>
              <div>{p.options.map(o => <div key={o.id}>{o.text} — {o.votes || 0}</div>)}</div>
            </div>
          ))}
        </div>

        <div className="card chat-box">
          <h4>Chat</h4>
          <div className="chat-window">
            {chat.map((c, i) => <div key={i}><b>{c.name}:</b> {c.text}</div>)}
          </div>
          <div className="chat-input">
            <input value={msg} onChange={e=>setMsg(e.target.value)} placeholder="Message..." />
            <button onClick={sendChat}>Send</button>
          </div>
        </div>
      </div>
    </div>
  );
}
