import { configureStore, createSlice } from '@reduxjs/toolkit';

const initialUi = { role: null, name: '' };

const uiSlice = createSlice({
  name: 'ui',
  initialState: initialUi,
  reducers: {
    setRole(state, action) { state.role = action.payload; },
    setName(state, action) { state.name = action.payload; }
  }
});

export const { setRole, setName } = uiSlice.actions;

export const store = configureStore({
  reducer: {
    ui: uiSlice.reducer
  }
});
