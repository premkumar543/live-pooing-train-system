import React, { useEffect, useState } from 'react';
import { socket } from './socket';

export default function Teacher(){
  const [question, setQuestion] = useState('');
  const [optionsText, setOptionsText] = useState('Mars\nVenus\nJupiter\nSaturn');
  const [duration, setDuration] = useState(60);
  const [polls, setPolls] = useState([]);
  const [students, setStudents] = useState([]);
  const [chat, setChat] = useState([]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    socket.connect();
    socket.emit('teacher:register', {}, () => {});
    socket.on('server:polls_state', data => setPolls(data.polls || []));
    socket.on('server:poll_new', ({ poll }) => setPolls(p => [poll, ...p]));
    socket.on('server:poll_update', ({ poll }) => setPolls(prev => prev.map(x => x.id===poll.id?poll:x)));
    socket.on('server:poll_ended', ({ poll }) => setPolls(prev => prev.map(x => x.id===poll.id?poll:x)));
    socket.on('server:students_update', ({ students }) => setStudents(students));
    socket.on('server:chat_history', ({ chat }) => setChat(chat || []));
    socket.on('chat:new', (entry) => setChat(c => [...c, entry]));

    return () => { socket.off(); socket.disconnect(); };
  }, []);

  function createPoll(){
    const opts = optionsText.split('\n').map(s => s.trim()).filter(Boolean);
    socket.emit('teacher:create_poll', { question, options: opts, duration: Number(duration) }, (resp) => {
      if (!resp.ok) alert('Error: ' + resp.error);
      else { setQuestion(''); setOptionsText(''); }
    });
  }

  function endPoll(id){
    socket.emit('teacher:end_poll', { pollId: id }, (r) => { if (!r.ok) alert(r.error); });
  }

  function kick(studentSocketId){
    socket.emit('teacher:kick', { socketId: studentSocketId }, (r) => {
      if (!r.ok) alert('Kick failed: ' + r.error);
    });
  }

  function sendChat(){
    if (!message.trim()) return;
    socket.emit('chat:send', { name: 'Teacher', text: message }, (r)=>{ if (r.ok) setMessage(''); });
  }

  return (
    <div className="teacher-wrap">
      <header><h2>Teacher Dashboard</h2></header>
      <div className="teacher-grid">
        <div className="left">
          <div className="card">
            <h3>Let's Get Started</h3>
            <label>Enter your question</label>
            <input value={question} onChange={e=>setQuestion(e.target.value)} placeholder="Type question..." />
            <div className="row">
              <label>Duration</label>
              <select value={duration} onChange={e=>setDuration(e.target.value)}>
                <option>30</option>
                <option>45</option>
                <option>60</option>
                <option>90</option>
              </select>
            </div>
            <label>Edit Options (one per line)</label>
            <textarea rows={4} value={optionsText} onChange={e=>setOptionsText(e.target.value)} />
            <div className="actions">
              <button onClick={createPoll}>Ask Question</button>
            </div>
          </div>

          <div className="card">
            <h4>Polls / Live Results</h4>
            {polls.map(p => (
              <div key={p.id} className="poll-card">
                <div className="poll-q">{p.question} {p.active && <span className="badge">Active</span>}</div>
                <div>
                  {p.options.map(o => {
                    const total = p.options.reduce((s, it)=> s+(it.votes || 0), 0) || 1;
                    const pct = Math.round(((o.votes || 0) / total) * 100);
                    return <div key={o.id} className="bar-row">{o.text} — {o.votes || 0} votes ({pct}%)</div>;
                  })}
                </div>
                {p.active && <button onClick={()=>endPoll(p.id)}>End Poll</button>}
              </div>
            ))}
          </div>
        </div>

        <div className="right">
          <div className="card">
            <h4>Participants</h4>
            {students.map(s => (
              <div key={s.socketId} className="student-row">
                <span>{s.name}</span>
                <button onClick={()=>kick(s.socketId)}>Kick out</button>
              </div>
            ))}
          </div>

          <div className="card">
            <h4>Chat</h4>
            <div className="chat-window">
              {chat.map((c, idx) => <div key={idx} className="chat-entry"><b>{c.name}:</b> {c.text}</div>)}
            </div>
            <div className="chat-input">
              <input value={message} onChange={e=>setMessage(e.target.value)} placeholder="Message..." />
              <button onClick={sendChat}>Send</button>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
