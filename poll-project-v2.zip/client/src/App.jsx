import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { setRole } from './store';
import Teacher from './Teacher';
import Student from './Student';

export default function App(){
  const [role, setR] = useState(null);
  const dispatch = useDispatch();

  if (!role) {
    return (
      <div className="landing">
        <div className="card-landing">
          <h1>Welcome to the Live Polling System</h1>
          <p>Please select the role that best describes you to begin using the live polling system</p>
          <div className="role-grid">
            <div className="role-card" onClick={() => { setR('student'); dispatch(setRole('student')); }}>
              <h3>I'm a Student</h3>
              <p>Submit answers and view live poll results</p>
            </div>
            <div className="role-card" onClick={() => { setR('teacher'); dispatch(setRole('teacher')); }}>
              <h3>I'm a Teacher</h3>
              <p>Create polls and monitor live responses</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return role === 'teacher' ? <Teacher /> : <Student />;
}
