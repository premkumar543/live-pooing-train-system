// server.js
const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*" },
});

const PORT = process.env.PORT || 4000;

// In-memory store (for demo)
const polls = {}; // pollId -> poll
const students = {}; // socketId -> { name, socketId }
const teachers = new Set();
const chat = []; // {from, name, text, ts}

function broadcastPolls() {
  io.emit("server:polls_state", { polls: Object.values(polls) });
}

io.on("connection", (socket) => {
  console.log("connect", socket.id);

  socket.on("student:join", (payload, ack) => {
    const name = (payload && payload.name) ? payload.name : `Student-${socket.id.slice(0,4)}`;
    students[socket.id] = { name, socketId: socket.id, joinedAt: Date.now() };
    socket.emit("server:joined", { socketId: socket.id, name });
    io.emit("server:students_update", { students: Object.values(students) });
    socket.emit("server:polls_state", { polls: Object.values(polls) });
    socket.emit("server:chat_history", { chat });
    if (ack) ack({ ok: true });
  });

  socket.on("teacher:register", (payload, ack) => {
    teachers.add(socket.id);
    io.emit("server:teacher_update", { teacherOnline: true });
    if (ack) ack({ ok: true });
  });

  socket.on("teacher:create_poll", (payload, ack) => {
    const id = payload.id || `poll_${Date.now()}`;
    if (!payload || !payload.question || !Array.isArray(payload.options) || payload.options.length < 2) {
      if (ack) ack({ ok: false, error: "invalid payload" });
      return;
    }
    // can't create if active poll exists
    const anyActive = Object.values(polls).some(p => p.active);
    if (anyActive) {
      if (ack) ack({ ok: false, error: "There is already an active poll" });
      return;
    }
    const opts = payload.options.map((text, idx) => ({ id: idx+1, text, votes: 0 }));
    polls[id] = {
      id,
      question: payload.question,
      options: opts,
      active: true,
      createdBy: socket.id,
      startedAt: Date.now(),
      duration: payload.duration || 60,
      answers: {}, // socketId -> optionId
      answersCount: 0,
    };
    io.emit("server:poll_new", { poll: polls[id] });

    // auto end after duration
    setTimeout(() => {
      const p = polls[id];
      if (p && p.active) {
        p.active = false;
        io.emit("server:poll_ended", { poll: p });
        broadcastPolls();
      }
    }, (polls[id].duration || 60) * 1000);

    if (ack) ack({ ok: true, poll: polls[id] });
  });

  socket.on("student:answer", (payload, ack) => {
    const p = polls[payload.pollId];
    if (!p || !p.active) {
      if (ack) ack({ ok: false, error: "Poll not active" });
      return;
    }
    p.answers = p.answers || {};
    if (p.answers[socket.id]) {
      if (ack) ack({ ok: false, error: "Already answered" });
      return;
    }
    p.answers[socket.id] = payload.optionId;
    const opt = p.options.find(o => o.id === payload.optionId);
    if (opt) opt.votes = (opt.votes || 0) + 1;
    p.answersCount = Object.keys(p.answers).length;

    const totalStudents = Object.keys(students).length;
    if (totalStudents > 0 && p.answersCount >= totalStudents) {
      p.active = false;
      io.emit("server:poll_ended", { poll: p });
    } else {
      io.emit("server:poll_update", { poll: p });
    }

    if (ack) ack({ ok: true });
  });

  socket.on("teacher:end_poll", (payload, ack) => {
    const p = polls[payload.pollId];
    if (p && p.active) {
      p.active = false;
      io.emit("server:poll_ended", { poll: p });
      if (ack) ack({ ok: true });
      return;
    }
    if (ack) ack({ ok: false, error: "No active poll or poll not found" });
  });

  // Chat related
  socket.on("chat:send", (payload, ack) => {
    const entry = { fromSocket: socket.id, name: payload.name || 'Anonymous', text: payload.text, ts: Date.now() };
    chat.push(entry);
    io.emit("chat:new", entry);
    if (ack) ack({ ok: true });
  });

  // Kick out student by socketId
  socket.on("teacher:kick", (payload, ack) => {
    const sId = payload.socketId;
    if (students[sId]) {
      // notify kicked client
      io.to(sId).emit("server:kicked", { reason: payload.reason || 'Removed by teacher' });
      // disconnect socket
      try { io.sockets.sockets.get(sId)?.disconnect(); } catch(e){}
      delete students[sId];
      io.emit("server:students_update", { students: Object.values(students) });
      if (ack) ack({ ok: true });
      return;
    }
    if (ack) ack({ ok: false, error: "Student not found" });
  });

  socket.on("disconnect", (reason) => {
    delete students[socket.id];
    teachers.delete(socket.id);
    io.emit("server:students_update", { students: Object.values(students) });
  });

});

app.get('/api/polls', (req, res) => res.json({ polls: Object.values(polls) }));
app.get('/api/students', (req, res) => res.json({ students: Object.values(students) }));
app.get('/api/chat', (req, res) => res.json({ chat }));

server.listen(PORT, () => console.log('Server listening on', PORT));
