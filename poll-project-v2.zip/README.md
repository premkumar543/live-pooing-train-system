Live Polling System - Deployment Ready
-------------------------------------

What's included:
- server/: Express + Socket.IO backend (chat + kick + poll timer)
- client/: Vite + React + Redux frontend (Teacher + Student + Chat + Kick)

Run locally:
1) Backend
   cd server
   npm install
   npm start

2) Frontend
   cd client
   npm install
   # copy .env.example to .env and set VITE_SERVER_URL if backend not on localhost
   npm run dev

Quick deploy guide:
- Backend: Render or Railway recommended
  * Create new Web Service (Node)
  * Link GitHub repo or deploy by pushing code
  * Set start command: `node server.js`
  * Ensure port env is available (Render sets PORT)

- Frontend: Vercel recommended
  * Create a new project, link repo
  * Set Environment Variable VITE_SERVER_URL to your backend URL
  * Build command: `npm run build`, Output directory: `dist`

After deployment, use the hosted frontend URL as your assignment link.

If you'd like, I can deploy it for you (I will need either temporary deployment credentials or permission to use my own hosting). Otherwise, deploy with the above steps and I'll help verify & troubleshoot.

